function setURL(URL4D) {
       window.location.href = (URL4D);
}

function changeBkgColor(vColor)  {   
       document.body.style.backgroundColor = '#'+vColor;
}

function changeColumns(numColumns) {
	document.getElementById('content').style['-webkit-column-count']=numColumns;
	
}

function changeCSSProperty(vDomObject,vCssProperty,CssValue) {
	document.getElementById(vDomObject).style[vCssProperty]=CssValue;
	
}

function changeFontSize(vTag,vCssProperty,CssValue) {
	//document.getElementById(vDomObject).style[vCssProperty]=CssValue;
	
	var elements = document.getElementsByTagName(vTag);
		for(var i = 0; i < elements.length; i++) {
			elements.item(i).style[vCssProperty] = CssValue;
		}
	
	
}