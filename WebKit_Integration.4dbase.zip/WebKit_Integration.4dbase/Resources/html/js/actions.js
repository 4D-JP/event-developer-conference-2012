function setURL(URL4D) {
       window.location.href = (URL4D);
}

function changeBkgColor(vColor)  {   
       document.body.style.backgroundColor = '#'+vColor;
}

function changeColumns(numColumns) {
	document.getElementById('content').style['-webkit-column-count']=numColumns;
	
}

function changeCSSProperty(vDomObject,vCssProperty,CssValue) {
	document.getElementById(vDomObject).style[vCssProperty]=CssValue;
	
}

function changeFontSize(vTag,vCssProperty,CssValue) {
	//document.getElementById(vDomObject).style[vCssProperty]=CssValue;
	
	var elements = document.getElementsByTagName(vTag);
		for(var i = 0; i < elements.length; i++) {
			elements.item(i).style[vCssProperty] = CssValue;
		}
	
	
}

function focus_country(countryCode) {

	if(countryCode=="ini") {
		WorldMap({
			id: "worldmap",
			bgcolor: "#ccdeeb",
			fgcolor: "#cccccc",
			bordercolor: "#7f7e7f",
			borderwidth: 0.5,
			padding: 10
		});
	} else {
		oSettings = {};
		oSettings.id = "worldmap";
		oSettings.bgcolor =  "#ccdeeb";
		oSettings.fgcolor = "#cccccc";
		oSettings.bordercolor = "#7f7e7f";
		oSettings.borderwidth = 0.5;
		oSettings.padding = 100;
		oSettings.zoom = countryCode;
		sDetail = countryCode;
		oSettings.detail = {};
		oSettings.detail[sDetail] ="#ce3633";
		WorldMap(oSettings);
	}
}